ADIL INTERN - COLLEGE INTERNSHIP PORTAL
=======================================

This build uses the MySQL database configured in config/database.php.
It requires PHP with PDO and the pdo_mysql extension enabled, and access to the database host.

DATABASE SETUP
1. Open your database provider's SQL/phpMyAdmin panel.
2. Select database db_455pavfps.
3. Import database.sql to create the users, students, companies, internships, and applications tables.
4. Ensure the database user has SELECT, INSERT, UPDATE, and DELETE permissions.
5. Ensure the host/provider allows connections from your PHP runtime.

RUN
From this folder, run: php -S 0.0.0.0:8080
Open the forwarded port 8080 URL.

If you see "could not find driver", enable/install pdo_mysql in the PHP runtime.
If you see "Access denied", verify the database username/password and permitted remote hosts.
If you see "Connection timed out", ask the database provider to confirm the host, port, and remote-access allowlist.

Security: credentials are stored in config/database.php for this project. Do not publish the ZIP or commit credentials to a public repository. Rotate the password if it has been exposed.
