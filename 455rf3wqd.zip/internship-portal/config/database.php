<?php
/** Adil Intern MySQL data layer. Requires PHP PDO MySQL (pdo_mysql). */
const DB_HOST = 'db01.dbhost.dev';
const DB_PORT = 5051;
const DB_NAME = 'db_455pavfps';
const DB_USER = 'user_455pavfps';
const DB_PASS = 'p455pavfps';

function db_connection(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);
    return $pdo;
}

function db_default(): array {
    return ['users'=>[], 'students'=>[], 'companies'=>[], 'internships'=>[], 'applications'=>[],
        'counters'=>['users'=>0,'students'=>0,'companies'=>0,'internships'=>0,'applications'=>0]];
}
function db_boot(): void {
    // Tables must be created by importing database.sql into the supplied database.
    db_connection();
}
function db_load(): array {
    $pdo = db_connection();
    $data = db_default();
    foreach (['users','students','companies','internships','applications'] as $table) {
        $data[$table] = $pdo->query("SELECT * FROM `$table` ORDER BY id")->fetchAll();
        $data['counters'][$table] = (int)$pdo->query("SELECT COALESCE(MAX(id),0) FROM `$table`")->fetchColumn();
    }
    return $data;
}
function db_save(array $data): bool {
    $pdo = db_connection();
    $tables = ['users','students','companies','internships','applications'];
    $columns = [
        'users'=>['id','name','email','password','role','created_at'],
        'students'=>['id','user_id','phone','college','course','skills','bio','resume'],
        'companies'=>['id','user_id','company_name','website','description'],
        'internships'=>['id','company_id','title','description','location','skills','duration','stipend','status','created_at'],
        'applications'=>['id','student_id','internship_id','status','applied_at'],
    ];
    // Delete removed rows child-first, then insert/update parent-first to respect foreign keys.
    try {
        $pdo->beginTransaction();
        foreach (array_reverse($tables) as $table) {
            $ids = array_values(array_filter(array_map(fn($r)=>(int)($r['id']??0), $data[$table] ?? []), fn($id)=>$id>0));
            if (!$ids) { $pdo->exec("DELETE FROM `$table`"); continue; }
            $marks = implode(',', array_fill(0, count($ids), '?'));
            $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id NOT IN ($marks)");
            $stmt->execute($ids);
        }
        foreach ($tables as $table) {
            $cols = $columns[$table];
            $quoted = implode(',', array_map(fn($c)=>"`$c`", $cols));
            $holders = implode(',', array_fill(0, count($cols), '?'));
            $updates = implode(',', array_map(fn($c)=>"`$c`=VALUES(`$c`)", array_filter($cols, fn($c)=>$c!=='id')));
            $stmt = $pdo->prepare("INSERT INTO `$table` ($quoted) VALUES ($holders) ON DUPLICATE KEY UPDATE $updates");
            foreach (($data[$table] ?? []) as $row) {
                $values = [];
                foreach ($cols as $col) $values[] = $row[$col] ?? null;
                $stmt->execute($values);
            }
        }
        $pdo->commit();
        return true;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('Adil Intern database save failed: ' . $e->getMessage());
        return false;
    }
}
function db_next_id(array &$data, string $table): int {
    $data['counters'][$table] = (int)($data['counters'][$table] ?? 0) + 1;
    return $data['counters'][$table];
}
function db_now(): string { return date('Y-m-d H:i:s'); }
function db_find_user_by_email(array $data, string $email): ?array {
    foreach ($data['users'] as $user) if (strcasecmp((string)$user['email'], $email)===0) return $user;
    return null;
}
function db_user(array $data, int $id): ?array { foreach ($data['users'] as $row) if ((int)$row['id']===$id) return $row; return null; }
function db_student_by_user(array $data, int $id): ?array { foreach ($data['students'] as $row) if ((int)$row['user_id']===$id) return $row; return null; }
function db_company_by_user(array $data, int $id): ?array { foreach ($data['companies'] as $row) if ((int)$row['user_id']===$id) return $row; return null; }
function db_company(array $data, int $id): ?array { foreach ($data['companies'] as $row) if ((int)$row['id']===$id) return $row; return null; }
function db_internship(array $data, int $id): ?array { foreach ($data['internships'] as $row) if ((int)$row['id']===$id) return $row; return null; }
function db_sort_newest(array &$rows, string $field='created_at'): void { usort($rows, fn($a,$b)=>strcmp((string)($b[$field]??''),(string)($a[$field]??''))); }
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function flash(string $type, string $message): void { $_SESSION['flash']=['type'=>$type,'message'=>$message]; }
function take_flash(): ?array { $flash=$_SESSION['flash']??null; unset($_SESSION['flash']); return $flash; }
function require_role(string $role, string $loginPath='../login.php'): void { if (!isset($_SESSION['user_id']) || ($_SESSION['role']??'')!==$role) { header('Location: '.$loginPath); exit; } }
function status_class(string $status): string { return strtolower(str_replace(' ','-',$status)); }
?>
